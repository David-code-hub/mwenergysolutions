import{F as f}from"./BMRKVrRV.js";export{f as default};
